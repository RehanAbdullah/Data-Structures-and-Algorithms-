#ifndef ANY_H
#define ANY_H

typedef void * any;

#endif
